<?php

class Page404Content
{
    public function __construct()
    {
        echo '<h1 class="center">404</h1>';
    }
}