<?php

class DBConfig{
    public static $DBCHARSET = "utf8";
    
    // local
    public static $DBHOST = "localhost";
    public static $DBNAME = "site1614";
    public static $DBUSER = "root";
    public static $DBPASS = "kljh76RRenJh7";
    
    // hosting
    /*
    public static $DBHOST = "localhost";
    public static $DBNAME = "u0210881_default";
    public static $DBUSER = "u0210881_stream";
    public static $DBPASS = "GXmP2NOn";
    */
}