<?php


class FakeUserDataParser extends UserDataParser
{
    public function parse(){
        return "76561198370245401";
    }
}