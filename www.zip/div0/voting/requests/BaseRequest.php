<?php

//include_once ("../../../remote/Remote.php");
class BaseRequest extends Remote
{
    public function __construct()
    {
        parent::__construct();
    }
}