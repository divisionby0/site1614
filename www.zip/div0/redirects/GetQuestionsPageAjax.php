<?php
$response = array("url"=>"http://".$_SERVER['HTTP_HOST']."/qa/");
echo json_encode($response);