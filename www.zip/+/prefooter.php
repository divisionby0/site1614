			<div class="prefooter">
		
				<div class="uncover"  style="margin-bottom:30px">
					<h6><a href="#">Сводки</a></h6>
					<p>Новости CS:GO из&nbsp;различных источников, собранные в&nbsp;одном месте</p>
					<ul>
						<li><a href="#">из Твиттера</a></li>
						<li><a href="#">из Вконтакта</a></li>
						<li><a href="#">из Фейсбука</a></li>
						<li>из Ютуба</li>
					</ul>
				</div>
				
				<div class="uncover">
					<h6><a href="#">Киберспорт</a></h6>
					<p>Освещение CS:GO в&nbsp;качестве киберспортивной дисциплины</p>
					<ul>
						<li><a href="#">Турниры</a></li>
						<li><a href="#">Ближайшие матчи</a></li>
						<li><a href="#">Команды</a></li>
					</ul>
				</div>
				<div class="uncover">
					<h6><a href="#">Веды</a></h6>
					<p>Обучение игры в&nbsp;CS:GO. Статьи о&nbsp;тактиках и&nbsp;страгиях игры, фишках контры и&nbsp;правильных настройках</p>
					<ul>
						<li><a href="#">Карты</a></li>
						<li><a href="#">Игра за Т и СТ</a></li>
						<li><a href="#">Раскидка гранат</a></li>
					</ul>
				</div>
				
					<div class="uncover"   style="margin-bottom:30px"> 
					<h6><a href="#">Вопросы</a></h6>
					<p>Форум по&nbsp;игре CS:GO. Задаешь вопросы&nbsp;&mdash; получаешь ответы</p>
					<ul>
						<li><a href="#">Технические вопросы</a></li>
						<li><a href="#">Опросы</a></li>
						<li><a href="#">Обсуждение команд</a></li>
						<li><a href="#">Сообщество</a></li>
					</ul>
				</div>
				
				
				<div class="uncover" >
					<h6><a href="#">Медиа</a></h6>
					<p>Творчество CS:GO: мемы, видео, обои и&nbsp;пр.</p>
					<ul>
						<li><a href="#">Видео</a></li>
						<li>Мемы</li>
					</ul>
				</div>				
			</div>