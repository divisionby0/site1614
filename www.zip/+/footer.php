
<footer>
		<div class="f_ring">
			<div class="f_rring">
				<div>
					<ul>
						<li><a href="#">О проекте</a></li>
						<li><a href="#">Правила поведения</a></li>
					</ul>
					<ul>
						<li><a href="#">Мы Вконтакте</a></li>
					</ul>
						<img src="/i/temp_li.jpg" alt="">
				</div>
				<div class="copyright">
					<p>Сайт развивается с&nbsp;2015&nbsp;года командой единомышленников под&nbsp;руководством <a href="http://vk.com/skvsk">Алексея Сайковского</a></p>
					<form action="#">
						<input type="text" placeholder="поиск на сайте">
					</form>
				</div>
			</div>
		</div>
	</footer>
	
	<p id="back-top"><a href="#top"><span><img src="/i/up.png"/></span></a></p>
	<script src="/js/jquery.jscrollpane.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
	<script src="/js/lib/moment.min.js"></script>
	<!--<script src="/js/main.js"></script>-->
	<script src="/js/answerCreation.js"></script>
	<script src="/js/voting.js"></script>
	<script src="/js/scrolltotop.js"></script>

<?php

echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/iterators/ListIterator.js'></script>";
echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/iterators/MapIterator.js'></script>";
echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/json/MapJsonDecoder.js'></script>";
echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/json/MapJsonEncoder.js'></script>";
echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/List.js'></script>";
echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/collections/Map.js'></script>";

echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/div0/events/EventBus.js'></script>";

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/view/AddQuestionPageView.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/Voting.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/pining/RecordPining.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/pining/ajax/PinRecordAjaxRequest.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/QuestionVoting.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/deleting/QuestionDelete.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/deleting/ajax/DeleteQuestionAjaxRequest.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/deleting/AnswerDelete.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/deleting/ajax/DeleteAnswerAjaxRequest.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/QuestionEditTimeout.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/QuestionEdit.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/ajax/UpdateQuestionAjaxRequest.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/AnswerEditTimeout.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/AnswerEdit.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/editing/ajax/UpdateAnswerAjaxRequest.js"></script>';

echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/RatingControlsUpdate.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/QuestionNegativeDisabledRatingControlsUpdate.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/QuestionNegativeEnabledRatingControlsUpdate.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/QuestionDisabledRatingControlsUpdate.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/ajax/ChangeQuestionRatingAjaxRequest.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/ajax/GetQuestionRatingAjaxRequest.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/ajax/GetQuestionUserLastRatingValueAjaxRequest.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/GetQuestionsPageUrlAjaxRequest.js"></script>';
echo '<script src="http://'.$_SERVER['HTTP_HOST'].'/js/div0/voting/colors.js"></script>';
?>

	<script src="/js/div0/view/AnswerForm.js"></script>
	<!--<script src="/js/div0/voting/QuestionVoting.js"></script>-->
	<script src="/js/search.js"></script>
<script src="/js/main.js"></script>
