		<meta charset="utf-8">
		<link rel="stylesheet" href="/css/jquery.jscrollpane.css" type="text/css" />
		<link rel="stylesheet" href="/css/main.css" type="text/css" />
		<link rel="icon" href="/favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

		<?php
		//echo "<script type='application/javascript' src='http://".$_SERVER['HTTP_HOST']."/js/lib/jquery-3.1.0.js'></script>";
		?>

		<script src="/js/masonry.pkgd.min.js"></script>
		<meta name="yandex-verification" content="ca5dc611e8606a02" />