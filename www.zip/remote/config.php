<?php
if( !defined('STREAM_SUBSYSTEM')){
    die('sorry. STREAM_SUBSYSTEM not defined');
}

// local
define('DBHOST', 'localhost');
define('DBNAME', 'site1614');
define('DBUSER', 'root');
define('DBPASS', 'kljh76RRenJh7');

// host
/*
define('DBHOST', 'localhost');
define('DBNAME', 'u0210881_default');
define('DBUSER', 'u0210881_stream');
define('DBPASS', 'GXmP2NOn');
*/

define('DBCHARSET', 'utf8');
define('YANDEXTRANSLATEKEY', 'trnsl.1.1.20161222T143143Z.0e756f285611d01c.9740e22876f5297618090be8453112bd86ff96d4');
define('YOUTUBEKEY', 'AIzaSyANngJoHnJR_HxT8a8PLJBTTYfWKDT6ySA');
define('TWITTERCONSUMERKEY', 'y4u3h7PBoRNZv4bb9CO48M0Pj');
define('TWITTERCONSUMERSECRET', '2cSqZ1AyiCIpcmb4p7u3DCN6Gh6D1dpn1MbBZGt6qXDUCy9iDb');
define('TWITTERTOKEN', '119008483-n0FSCXIeoXerzUSvNopCuGoiHuxRoRV1xkahjpDo');
define('TWITTERTOKENSECRET', '4I1h0SlwKzCvjlJkif35d6OHnzYQePJbuCvXqcK34tiwH');
define('ENTRIESPERPAGE', 3);